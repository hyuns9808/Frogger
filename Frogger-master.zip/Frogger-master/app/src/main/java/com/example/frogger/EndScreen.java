package com.example.frogger;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EndScreen extends AppCompatActivity {
    private Button startGameButton;
    private Button quitGameButton;
    private TextView scoreView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);

        Intent i = getIntent();
        Bundle bFetch = i.getExtras();

        Integer iScore = bFetch.getInt("score");

        scoreView = findViewById(R.id.score);
        scoreView.setText(iScore.toString());

        startGameButton = findViewById(R.id.startGame);
        startGameButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(EndScreen.this, CharacterCustomization.class);
                        Bundle send = new Bundle();
                        send.putString("name", bFetch.getString("name"));
                        send.putString("sprite", bFetch.getString("sprite"));
                        send.putBoolean("fromEnd", true);
                        i.putExtras(send);
                        startActivity(i);
                    }
                }
        );

        quitGameButton = findViewById(R.id.quitGame);
        quitGameButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finishAffinity();
                    }
                }
        );
    }
}
