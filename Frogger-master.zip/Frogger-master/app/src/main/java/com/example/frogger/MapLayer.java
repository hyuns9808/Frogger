package com.example.frogger;

import android.graphics.Canvas;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;

public class MapLayer<E extends Renderable> implements Renderable {
    private Collection<E> entities;
    private GameModel gameModel;

    public MapLayer(GameModel gameModel, E singleElement) {
        this.gameModel = gameModel;
        entities = new HashSet<E>();
        entities.add(singleElement);
    }

    public MapLayer(GameModel gameModel, Collection<E> elements) {
        this.gameModel = gameModel;
        entities = new HashSet<E>();
        for (E element : elements) {
            entities.add(element);
        }
    }

    public MapLayer(GameModel gameModel, Map<Integer, E> elements) {
        this.gameModel = gameModel;
        entities = new HashSet<E>();
        for (E element : elements.values()) {
            entities.add(element);
        }
    }

    public void draw(Canvas canvas) {
        for (Renderable r : entities) {
            r.draw(canvas);
        }
    }
}
