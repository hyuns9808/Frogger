package com.example.frogger;

import android.content.Context;
import android.graphics.Canvas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class GameModel implements Renderable {

    private GameView gameView;
    private TileGrid tileGrid;
    private Tilemap tileMap;

    private List<Log> logMap;
    private HashMap<Integer, Vehicle> vehicleMap;
    private Character character;
    private List<MapLayer> layerList;

    public GameModel(Context context, GameView gameView, Character character) {
        layerList = new ArrayList<MapLayer>(6);

        this.gameView = gameView;

        // Initialize Maps
        tileMap = new Tilemap(context, R.drawable.tileset);
        tileGrid = new TileGrid(tileMap);

        logMap = LogSpawner.generateDefault(context, tileGrid);

        vehicleMap = VehicleSpawner.generateDefault(context, tileGrid);

        this.character = character;

        MapLayer<Tilemap> mapLayer = new MapLayer<>(this, tileMap);
        MapLayer<Log> entityLayer = new MapLayer<>(this, logMap);
        MapLayer<Vehicle> vehicleLayer = new MapLayer<>(this, vehicleMap);
        MapLayer<Character> characterLayer = new MapLayer<>(this, character);

        layerList.add(0, mapLayer);
        layerList.add(1, entityLayer);
        layerList.add(2, vehicleLayer);
        layerList.add(3, characterLayer);

    }

    public void draw(Canvas canvas) {
        for (MapLayer layer : layerList) {
            if (layer != null) {
                layer.draw(canvas);
            }
        }
    }

    public boolean checkCollisions() {
        if (GameView.getVehicleDebug()) {
            return false;
        }
        for (Vehicle v : vehicleMap.values()) {
            if (character.collide(v)) {
                return true;
            }
        }
        return false;
    }

    public boolean checkLogs() {
        for (Log l : logMap) {
            if (character.collide(l)) {
                return true;
            }
        }
        return false;
    }

    public boolean checkRiver() {
        if (GameView.getRiverDebug()) {
            return false;
        }
        return !checkLogs() && character.collideRiver();
    }

    public void fixedUpdate() {
        if (!GameView.PAUSE_DEBUG) {
            for (Vehicle v : vehicleMap.values()) {
                v.update();
            }

            for (Log l : logMap) {
                l.update();
            }
        }

        if (character.hasDied(character.getCharLives())) {
            gameView.loseGame();
        }

        if (character.getY() == 0) {
            gameView.winGame();
        }

        gameView.tick();
    }

}
