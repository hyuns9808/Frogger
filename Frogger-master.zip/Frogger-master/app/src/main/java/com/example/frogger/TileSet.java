package com.example.frogger;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.util.HashMap;

public class TileSet {
    private Bitmap bmp;

    private HashMap<Tiles, Bitmap> tileSet;

    public TileSet(Context context, int drawableID, int tileWidth, int tileHeight) {
        bmp = BitmapFactory.decodeResource(context.getResources(), R.drawable.tileset);
        tileSet = new HashMap<Tiles, Bitmap>();

        tileSet.put(Tiles.NULL,
                BitmapFactory.decodeResource(context.getResources(), R.drawable.tileset));
        tileSet.put(Tiles.SAFE,
                BitmapFactory.decodeResource(context.getResources(), R.drawable.tilesafe));
        tileSet.put(Tiles.ROAD,
                BitmapFactory.decodeResource(context.getResources(), R.drawable.tileroad));
        tileSet.put(Tiles.RIVER,
                BitmapFactory.decodeResource(context.getResources(), R.drawable.tileriver));
        tileSet.put(Tiles.GOAL,
                BitmapFactory.decodeResource(context.getResources(), R.drawable.tilegoal));
    }

    public Bitmap getTileBitmap(Tiles tileID) {
        return tileSet.get(tileID);
    }

}
