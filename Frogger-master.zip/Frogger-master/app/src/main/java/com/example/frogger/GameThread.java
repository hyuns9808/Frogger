package com.example.frogger;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class GameThread extends Thread {
    private SurfaceHolder surfaceHolder;
    private GameView gameView;
    private boolean running;

    public GameThread(GameView gameView, SurfaceHolder surfaceHolder) {
        super();
        this.surfaceHolder = surfaceHolder;
        this.gameView = gameView;
    }

    public void begin() {
        running = true;
        start();
    }

    public void end() {
        running = false;
    }

    @Override
    public void run() {
        super.run();

        int clkCount = 0;

        long startTime = 0;
        long deltaTime = 0;
        long sleepTime = 0;

        Canvas canvas;
        while (running) {
            try {
                canvas = surfaceHolder.lockCanvas();
                synchronized (surfaceHolder) {
                    gameView.getModel().fixedUpdate();
                    boolean anyCollisions = gameView.getModel().checkCollisions()
                            || gameView.getModel().checkRiver();
                    if (anyCollisions) {
                        System.out.println("collision!");
                    }
                    gameView.draw(canvas);
                }
                surfaceHolder.unlockCanvasAndPost(canvas);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }

            clkCount++;

            sleepTime = (long) (clkCount * (1000 / GameView.FPS) - deltaTime);
            if (sleepTime > 0) {
                try {
                    sleep(sleepTime);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            deltaTime = System.currentTimeMillis() - startTime;
            if (deltaTime >= 1000) {
                startTime = System.currentTimeMillis();
                clkCount = 0;
            }
        }
    }
}
