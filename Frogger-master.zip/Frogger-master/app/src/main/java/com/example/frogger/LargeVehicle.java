package com.example.frogger;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class LargeVehicle extends Vehicle {

    private int width;

    private Rect maskRect;

    public LargeVehicle(Context context, int x, int y,
                        boolean direction, int speed, int width, TileGrid tileGrid) {
        super(context, x, y, direction, speed, tileGrid);
        this.width = width;
    }

    @Override
    public void setDrawables(int right, int left) {
        this.right = BitmapFactory.decodeResource(context.getResources(), right);
        this.left = BitmapFactory.decodeResource(context.getResources(), left);
    }

    @Override
    public void draw(Canvas canvas) {
        drawRect = tileGrid.getRect(x, y, width, 1);

        Paint paint = new Paint();
        Paint mask = new Paint();
        paint.setColor(Color.RED);
        mask.setColor(Color.BLACK);

        if (direction) {
            if (right != null) {
                canvas.drawBitmap(right, null, drawRect, null);
            } else {
                canvas.drawRect(drawRect, paint);
            }
        } else {
            if (left != null) {
                canvas.drawBitmap(left, null, drawRect, null);
            } else {
                canvas.drawRect(drawRect, paint);
            }
        }
        if (x < 0) {
            maskRect = tileGrid.getCell(x, y);
            canvas.drawRect(maskRect, mask);
        } else if (x >= 8) {
            maskRect = tileGrid.getCell(x + 1, y);
            canvas.drawRect(maskRect, mask);
        }
    }

    @Override
    public void update() {
        if (speed > 0 && GameView.getTick()
                % (GameView.SPEED_DEBUG * (GameView.FPS / speed)) == 0) {
            if (direction) {
                if (x + 1 > 8) {
                    x = -1;
                } else {
                    x++;
                }
            } else {
                if (x - 1 < -1) {
                    x = 8;
                } else {
                    x--;
                }
            }
        }
    }
}
