package com.example.frogger;

import android.graphics.Canvas;

public abstract class MapEntity implements Renderable {

    public abstract void draw(Canvas canvas);
}
