package com.example.frogger;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class Vehicle implements Renderable {

    protected Context context;
    protected int speed;
    protected boolean direction; // false = left, true = right
    protected Bitmap right;
    protected Bitmap left;
    protected Rect drawRect;

    protected int x;

    protected final int y; // lane height
    protected TileGrid tileGrid;

    protected Canvas canvas;

    public Vehicle(Context context, int x, int y, boolean direction, int speed, TileGrid tileGrid) {
        this.context = context;
        this.x = x;
        this.y = y;
        this.tileGrid = tileGrid;
        this.speed = speed;
        this.direction = direction;
    }
    public void setDrawables(int right, int left) {
        this.right = BitmapFactory.decodeResource(context.getResources(), right);
        this.left = BitmapFactory.decodeResource(context.getResources(), left);
    }

    public boolean getDirection() {
        return direction;
    }

    public static int calculateSpeed(int y) {
        int speed = 0;
        if (y == 8 || y == 13) {
            speed = 1;
            // sprite
        } else if (y == 9 || y == 12) {
            speed = 2;
        } else if (y == 10 || y == 11) {
            speed = 3;
        }
        return speed;
    }

    public static boolean calculateDirection(int y) {
        if (y >= 8 && y <= 13) {
            return y % 2 != 0;
        }
        throw new IllegalArgumentException("y is not on the road");
    }

    public static int calculateStartingX(int y) {
        return y % 2 != 0 ? 8 : 0;
    }

    // get x and y for collisions
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }

    public void move() {
        if (canMove(x)) {
            x = direction ? x + 1 : x - 1;
        }
    }

    public static boolean canMove(int x) {
        return x - 1 != -1 && x + 1 != 9;
    }

    public void draw(Canvas canvas) {
        drawRect = tileGrid.getCell(x, y);
        Paint paint = new Paint();
        paint.setColor(Color.RED);

        if (direction) {
            if (right != null) {
                canvas.drawBitmap(right, null, drawRect, null);
            } else {
                canvas.drawRect(drawRect, paint);
            }
        } else {
            if (left != null) {
                canvas.drawBitmap(left, null, drawRect, null);
            } else {
                canvas.drawRect(drawRect, paint);
            }
        }
    }

    public void update() {
        if (speed > 0
                && GameView.getTick() % (GameView.SPEED_DEBUG * (GameView.FPS / speed)) == 0) {
            if (direction) {
                if (x + 1 > 8) {
                    x = 0;
                } else {
                    x++;
                }
            } else {
                if (x - 1 < 0) {
                    x = 8;
                } else {
                    x--;
                }
            }
        }
    }
}
