package com.example.frogger;

import android.graphics.Rect;

public class TileGrid {
    private int offSetX;
    private int offSetY;

    private int cellSize;
    private int scale;

    public TileGrid(int x, int y, int size, int scale) {
        offSetX = x;
        offSetY = y;

        cellSize = size;
        this.scale = scale;
    }

    public TileGrid(Tilemap tm) {
        offSetX = tm.getOffSetX();
        offSetY = tm.getOffSetY();

        cellSize = tm.getTileWidth();
        scale = tm.getScale();
    }

    private int[] getCoordinates(int x, int y, int w, int h) {
        int originX = offSetX + (x * cellSize * scale);
        int originY = offSetY + (y * cellSize * scale);
        int tX = offSetX + (x * cellSize * scale);
        int tY = offSetY + (y * cellSize * scale);
        int bX = offSetX + ((x + w) * cellSize * scale);
        int bY = offSetY + ((y + h) * cellSize * scale);

        return new int[] {originX, originY, tX, tY, bX, bY };
    }

    public Rect getCell(int x, int y) {
        int[] coords = getCoordinates(x, y, 1, 1);
        return new Rect(coords[0], coords[1], coords[4], coords[5]);
    }

    public Rect getRect(int x, int y, int w, int h) {
        int[] coords = getCoordinates(x, y, w, h);
        return new Rect(coords[2], coords[3], coords[4], coords[5]);
    }

}
