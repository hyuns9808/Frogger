package com.example.frogger;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.content.Context;
import android.graphics.Canvas;

import androidx.annotation.NonNull;

import java.util.HashMap;

public class GameView extends SurfaceView {

    private Activity activity;
    private Context context;
    private Canvas canvas;
    private GameThread gameThread;

    private int y;

    // IMPORTANT GLOBALS

    public static final int FPS = 24;
    // MANAGER OBJECTS
    private GameManager gameManager;
    // CONTROLS
    private DPad dPad;
    private DebugButton dButton;
    // GAME OBJECTS
    private TileGrid tileGrid;
    private GameModel gameModel;
    private Tilemap tilemap;
    private Character character;

    public static final int SPEED_DEBUG = 1;
    public static final boolean PAUSE_DEBUG = false;
    private static boolean vehicleDebug = false;
    private static boolean riverDebug = false;
    private HashMap<Integer, Vehicle> vehicleMap;

    private int pDifficulty = CharacterCustomization.getDifficulty();

    private String pName = CharacterCustomization.getName();

    private String pSprite = CharacterCustomization.getSprite();

    // Game State Info

    private static int localTick;

    @Deprecated
    public GameView(Context context) {
        super(context);

        tilemap = new Tilemap(context, R.drawable.tileset);
        character = new Character(context, 0, "Charli", "Sprite 1", tilemap, tileGrid);
        vehicleMap = new HashMap<>();

        SurfaceHolder surfaceHolder = getHolder();

        gameThread = new GameThread(this, surfaceHolder);
        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {

                gameThread.begin();

            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder,
                                       int i, int i1, int i2) {

            }

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {

            }
        });

    }

    public GameView(Context context, Bundle bFetch, Activity activity) {

        super(context);
        this.activity = activity;

        localTick = 0;

        tilemap = new Tilemap(context, R.drawable.tileset);
        tileGrid = new TileGrid(tilemap);
        character = new Character(context, bFetch.getInt("difficulty"),
                bFetch.getString("name"), bFetch.getString("sprite"), tilemap, tileGrid);

        gameModel = new GameModel(context, this, character);
        gameManager = new GameManager(context, character);

        dPad = new DPad(200, 1880, 48, character);
        dButton = new DebugButton(600, 1880);

        SurfaceHolder surfaceHolder = getHolder();

        gameThread = new GameThread(this, surfaceHolder);

        this.context = context;
        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {

                gameThread.begin();

            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder,
                                       int i, int i1, int i2) {

            }

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {

            }
        });
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

        gameModel.draw(canvas);

        // UI LAYER
        if (gameManager != null) {
            gameManager.draw(canvas);
        }

        dPad.draw(canvas);

        dButton.draw(canvas);


    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (dPad.isPressed((double) event.getX(), (double) event.getY())) {
                int cardinalDir = dPad.getDirectionOutput(event.getX(), event.getY());
                character.move(cardinalDir);
            }
            if (dButton.isPressed((double) event.getX(), (double) event.getY())) {
                vehicleDebug = !vehicleDebug;
                riverDebug = !riverDebug;
            }
        }
        return super.onTouchEvent(event);
    }

    public void loseGame() {
        if (gameThread != null) {
            gameThread.end();
            gameThread.interrupt();
        }

        Intent i = new Intent(context, EndScreen.class);

        Bundle send = new Bundle();
        send.putString("name", character.getCharName());
        send.putInt("difficulty", character.getCharDiff());
        send.putString("sprite", character.getCharSprite());
        send.putInt("score", character.getScore());
        i.putExtras(send);

        context.startActivity(i, send);
        activity.finish();
    }

    public void winGame() {
        if (gameThread != null) {
            gameThread.end();
            gameThread.interrupt();
        }

        Intent i = new Intent(context, WinScreen.class);

        Bundle send = new Bundle();
        send.putString("name", character.getCharName());
        send.putInt("difficulty", character.getCharDiff());
        send.putString("sprite", character.getCharSprite());
        send.putInt("score", character.getScore());
        i.putExtras(send);

        context.startActivity(i, send);
        activity.finish();
    }

    public void testDraw(Canvas canvas) {
        canvas.drawColor(Color.BLUE);
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL);

        canvas.drawCircle(10, 10, 10, paint);
    }

    public void drawTileMap(Tilemap tilemap) {
        tilemap.draw(canvas);
    }

    public Canvas getCanvas() {
        return this.canvas;
    }

    public void update() {
    }

    public GameModel getModel() {
        return gameModel;
    }

    public void fixedUpdate() {
        for (Vehicle v : vehicleMap.values()) {
            v.update();
        }

        if (character.hasDied(character.getCharLives())) {
            loseGame();
        }

        if (character.getY() == 0) {
            winGame();
        }
    }

    public static void tick() {
        localTick = (localTick + 1) % (FPS * SPEED_DEBUG);
    }

    // returns true if there is ANY collision
    public boolean checkCollisions() {
        for (Vehicle v : vehicleMap.values()) {
            if (character.collide(v)) {
                return true;
            }
        }
        return false;
    }

    public static boolean willGameTerminate(int charLives) {
        if (charLives <= 0) {
            return true;
        }
        return false;
    }

    public static int getTick() {
        return localTick;
    }

    public static boolean getVehicleDebug() {
        return vehicleDebug;
    }

    public static boolean getRiverDebug() {
        return riverDebug;
    }
}
