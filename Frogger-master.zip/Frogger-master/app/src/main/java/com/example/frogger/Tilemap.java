package com.example.frogger;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Tilemap implements Renderable {
    private Bitmap bitmap;
    private static final int TILE_WIDTH = 16;
    private static final int MAP_WIDTH = 9;
    private static final int MAP_HEIGHT = 14;
    private int offSetX;
    private int offSetY;
    private int x;
    private Tiles[][] tileMap;
    private TileSet tileSet;
    private TileGrid tileGrid;
    private int displayScale;
    private Rect tileRect;

    public Tilemap(Context context, int drawableID) {
        offSetX = 32;
        offSetY = 200;

        this.tileMap = buildMapDefault();
        this.tileSet = new TileSet(context, R.drawable.tileset, 16, 16);
        this.bitmap = BitmapFactory.decodeResource(context.getResources(), drawableID);

        System.out.println(bitmap);
        x = 10;
        displayScale = 7;

        tileRect = new Rect(0, 0, getTileWidth(), getTileWidth());

        this.tileGrid = new TileGrid(this);
    }

    public Tiles[][] buildMapDefault() {
        return new Tiles[][]{
                {Tiles.GOAL, Tiles.GOAL, Tiles.GOAL, Tiles.GOAL, Tiles.GOAL, Tiles.GOAL,
                Tiles.GOAL, Tiles.GOAL, Tiles.GOAL},
                {Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER,
                Tiles.RIVER, Tiles.RIVER, Tiles.RIVER},
                {Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER,
                Tiles.RIVER, Tiles.RIVER, Tiles.RIVER},
                {Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER,
                Tiles.RIVER, Tiles.RIVER, Tiles.RIVER},
                {Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER,
                Tiles.RIVER, Tiles.RIVER, Tiles.RIVER},
                {Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER, Tiles.RIVER,
                Tiles.RIVER, Tiles.RIVER, Tiles.RIVER},
                {Tiles.SAFE, Tiles.SAFE, Tiles.SAFE, Tiles.SAFE, Tiles.SAFE, Tiles.SAFE,
                Tiles.SAFE, Tiles.SAFE, Tiles.SAFE},
                {Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD,
                Tiles.ROAD, Tiles.ROAD, Tiles.ROAD},
                {Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD,
                Tiles.ROAD, Tiles.ROAD, Tiles.ROAD},
                {Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD,
                Tiles.ROAD, Tiles.ROAD, Tiles.ROAD},
                {Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD,
                Tiles.ROAD, Tiles.ROAD, Tiles.ROAD},
                {Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD,
                Tiles.ROAD, Tiles.ROAD, Tiles.ROAD},
                {Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD, Tiles.ROAD,
                Tiles.ROAD, Tiles.ROAD, Tiles.ROAD},
                {Tiles.SAFE, Tiles.SAFE, Tiles.SAFE, Tiles.SAFE, Tiles.SAFE, Tiles.SAFE,
                Tiles.SAFE, Tiles.SAFE, Tiles.SAFE}
        };
    }

    public void draw(Canvas canvas) {
        Rect cell = new Rect(0, 0, 32, 32);
        for (int y = 0; y < 14; y++) {
            for (int x = 0; x < 9; x++) {
                cell = tileGrid.getCell(x, y);
                canvas.drawBitmap(tileSet.getTileBitmap(tileMap[y][x]), null, cell, null);

            }
        }
    }

    public static int getWidth() {
        return MAP_WIDTH;
    }

    public static int getHeight() {
        return MAP_HEIGHT;
    }

    public int getScale() {
        return displayScale;
    }

    public static int getTileWidth() {
        return TILE_WIDTH;
    }

    public int getOffSetX() {
        return offSetX;
    }

    public int getOffSetY() {
        return offSetY;
    }

}
