package com.example.frogger;

import android.graphics.Canvas;

public interface Renderable {
    public void draw(Canvas canvas);
}
