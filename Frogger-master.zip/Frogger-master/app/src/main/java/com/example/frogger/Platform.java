package com.example.frogger;

public interface Platform {
    public boolean move();
}
