package com.example.frogger;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

public class GameManager {
    private Character character;

    public GameManager(Context context, Character character) {
        this.character = character;
        // BITMAPS

    }

    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(48);

        int referenceY;
        try {
            referenceY = canvas.getHeight();
        } catch (Exception e) {
            referenceY = 100;
        }

        String difficulty = (character.getCharDiff() == 0)
                ? "Easy" : (character.getCharDiff() == 1) ? "Medium" : "Hard";
        String score = Integer.toString(character.getScore());
        String lives = Integer.toString(character.getCharLives());

        // DRAW TEXT
        canvas.drawText(character.getCharName(), 48, 48, paint);
        canvas.drawText(difficulty, 800, 48, paint);
        canvas.drawText("Lives: " + lives, 400, referenceY - 52, paint);
        canvas.drawText("Score: " + score, 800, referenceY - 52, paint);
    }

    public String getSprite() {
        return character.getCharSprite();
    }
}
