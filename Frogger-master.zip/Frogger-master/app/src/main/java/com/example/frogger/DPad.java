package com.example.frogger;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class DPad implements Renderable {
    private Paint paint;
    private Rect up;
    private Rect down;
    private Rect left;
    private Rect right;
    private Rect col;
    private int centerX;
    private int centerY;
    private int cardinalDir;

    public DPad(int centerX, int centerY, int buttonWidth, Character character) {

        this.centerX = centerX;
        this.centerY = centerY;

        paint = new Paint();
        paint.setColor(0xffffffff);

        col = new Rect(
                centerX - 3 * (buttonWidth / 2),
                centerY - 3 * (buttonWidth / 2),
                centerX + 3 * (buttonWidth / 2),
                centerY + 3 * (buttonWidth / 2)
                );

        up = new Rect(centerX - (buttonWidth / 2),
                centerY - 3 * (buttonWidth / 2),
                centerX + (buttonWidth / 2),
                centerY - (buttonWidth / 2)
        );

        down = new Rect(centerX - (buttonWidth / 2),
                centerY + 3 * (buttonWidth / 2),
                centerX + (buttonWidth / 2),
                centerY + (buttonWidth / 2)
        );

        left = new Rect(centerX - 3 * (buttonWidth / 2),
                centerY - (buttonWidth / 2),
                centerX - (buttonWidth / 2),
                centerY + (buttonWidth / 2)
        );

        right = new Rect(centerX + 3 * (buttonWidth / 2),
                centerY - (buttonWidth / 2),
                centerX + (buttonWidth / 2),
                centerY + (buttonWidth / 2)
        );
    }

    public void draw(Canvas canvas) {
        canvas.drawRect(up, paint);
        canvas.drawRect(down, paint);

        canvas.drawRect(left, paint);
        canvas.drawRect(right, paint);
    }

    public boolean isPressed(double x, double y) {

        return col.contains((int) x, (int) y);
    }

    public int getDirectionOutput(double x, double y) {
        cardinalDir = -1;

        double angle = Math.atan2(centerY - y, x - centerX) * 180 / Math.PI;

        if (angle > -45.0 && angle <= 45.0) {
            cardinalDir = 3;
        } else if (angle > 45.0 && angle <= 135.0) {
            cardinalDir = 0;
        } else if ((angle > 135.0 && angle <= 180.0) || (angle >= -180.0 && angle < -135.0)) {
            cardinalDir = 2;
        } else if (angle > -135.0 && angle <= -45) {
            cardinalDir = 1;
        } else {
            cardinalDir = -1;
        }

        return cardinalDir;
    }
}
