package com.example.frogger;

public enum Tiles {
    NULL,
    SAFE,
    ROAD,
    RIVER,
    GOAL
}
