package com.example.frogger;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Log extends MapEntity implements Platform {
    private Bitmap left;
    private Bitmap right;
    private Bitmap middle;
    private Bitmap unit;
    private TileGrid tileGrid;
    public static final int MAX_WIDTH = 4;
    private int width;
    private int speed;
    private boolean direction;
    private int x;
    private int y;

    public Log(Context context, TileGrid tileGrid,
               int width, int speed, boolean dir, int x, int y) {
        this.tileGrid = tileGrid;

        if (context != null) {
            left = BitmapFactory.decodeResource(context.getResources(), R.drawable.logs1);
            right = BitmapFactory.decodeResource(context.getResources(), R.drawable.logs3);
            middle = BitmapFactory.decodeResource(context.getResources(), R.drawable.logs2);
            unit = BitmapFactory.decodeResource(context.getResources(), R.drawable.logs4);
        }

        this.width = width;
        this.speed = speed;
        this.direction = dir;

        this.x = x;
        this.y = y;
    }

    public void draw(Canvas canvas) {
        if (width == 1) {
            if (x < 9 && x > -1) {
                canvas.drawBitmap(unit, null, tileGrid.getCell(x, y), null);
            }
        } else {
            for (int i = 0; i < width; i++) {
                if (i == 0) {
                    if (x + i < 9 && x + i > -1) {
                        canvas.drawBitmap(left, null, tileGrid.getCell(x, y), null);
                    }
                } else if (i == width - 1) {
                    if (x + i < 9 && x + i > -1) {
                        canvas.drawBitmap(right, null, tileGrid.getCell(x + i, y), null);
                    }
                } else {
                    if (x + i < 9 && x + i > -1) {
                        canvas.drawBitmap(middle, null, tileGrid.getCell(x + i, y), null);
                    }
                }
            }
        }

    }

    public boolean move() {
        if (speed > 0
                && GameView.getTick() % (GameView.SPEED_DEBUG * (GameView.FPS / speed)) == 0) {
            x = moveHelper(direction, x, width, MAX_WIDTH);
            return true;
        }
        return false;
    }

    public static int moveHelper(boolean direction, int x, int width, int maxWidth) {
        if (direction) {
            if (x + 1 > 8) {
                x = 1 - maxWidth;
            } else {
                x++;
            }
        } else {
            if (x - 1 < -width) {
                x = 7 + maxWidth;
            } else {
                x--;
            }
        }
        return x;
    }

    public boolean moveCheck() {
        try {
            GameView.getTick();
        } catch (Exception e) {
            return false;
        }
        return isRightTickToMove(GameView.getTick(), GameView.SPEED_DEBUG, GameView.FPS, speed);

    }

    public static boolean isRightTickToMove(int gameTick, int speedDebug,
                                            int gameFPS, int logSpeed) {
        return logSpeed > 0  && gameTick % (speedDebug * (gameFPS / logSpeed)) == 0;
    }

    public void update() {
        move();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public void setX(int i) {
        x = i;
    }

    public void setY(int i) {
        y = i;
    }

    public boolean getDirection() {
        return direction;
    }
}
