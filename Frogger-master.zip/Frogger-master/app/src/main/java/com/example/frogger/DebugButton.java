package com.example.frogger;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class DebugButton {
    private int x;
    private int y;
    private Rect button;
    private Paint paint;
    private boolean active;

    public DebugButton(int x, int y) {
        this.x = x;
        this.y = y;
        button = new Rect(x, y, x + 40, y + 40);

        active = false;

        paint = new Paint();
        paint.setColor(0xffffffff);
    }

    public void draw(Canvas canvas) {
        canvas.drawRect(button, paint);
    }

    public boolean isPressed(double x, double y) {
        if (button.contains((int) x, (int) y)) {
            active = !active;
            if (active) {
                paint.setColor(Color.GREEN);
            } else {
                paint.setColor(Color.WHITE);
            }
            return true;
        }
        return false;
    }


}
