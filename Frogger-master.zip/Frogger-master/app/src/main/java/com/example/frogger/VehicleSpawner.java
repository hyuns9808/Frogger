package com.example.frogger;

import android.content.Context;

import java.util.HashMap;

public class VehicleSpawner {
    private static TileGrid tileGrid;
    public static HashMap<Integer, Vehicle> generateDefault(
            Context context, TileGrid tileGridInput) {
        tileGrid = tileGridInput;

        HashMap<Integer, Vehicle> vehicleMap = new HashMap<>();

        for (int i = 1; i < 9; i += (i % 2 == 0 ? 4 : 3)) {
            vehicleMap.put(i + 12 * 9, generateYellow(context, i, 12, true));
        }

        for (int i = 0; i < 9; i += (i % 2 == 0 ? 3 : 4)) {
            vehicleMap.put(i + 11 * 9, generateRed(context, i, 11, true));
        }

        for (int i = 1; i < 6; i += (i % 2 == 0 ? 3 : 4)) {
            vehicleMap.put(i + 10 * 9, generateHOV(context, i, 10, true));
        }

        for (int i = 6; i >= 1; i -= (i % 2 == 0 ? 3 : 4)) {
            vehicleMap.put(i + 9 * 9, generateHOV(context, i, 9, false));
        }

        for (int i = 1; i < 9; i += (i % 2 == 0 ? 4 : 3)) {
            vehicleMap.put(i + 8 * 9, generateRed(context, i, 8, false));
        }

        for (int i = 7; i >= 0; i -= 4) {
            vehicleMap.put(i + 7 * 9, generateYellow(context, i, 7, false));
        }

        return vehicleMap;
    }



    private static Vehicle generateYellow(Context context, int x, int y, boolean direction) {
        Vehicle vehicle = new Vehicle(context, x, y, direction, 2, tileGrid);
        vehicle.setDrawables(R.drawable.yellow_broom_right, R.drawable.yellow_broom_left);

        return vehicle;
    }

    private static Vehicle generateRed(Context context, int x, int y, boolean direction) {
        Vehicle vehicle = new Vehicle(context, x, y, direction, 3, tileGrid);
        vehicle.setDrawables(R.drawable.red_broom2, R.drawable.red_broom1);
        return vehicle;
    }

    private static Vehicle generateHOV(Context context, int x, int y, boolean direction) {
        Vehicle vehicle = new LargeVehicle(context, x, y, direction, 1, 2, tileGrid);
        vehicle.setDrawables(R.drawable.tandem_broom2, R.drawable.tandem_broom1);
        return vehicle;
    }

}
