package com.example.frogger;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class CharacterCustomization extends AppCompatActivity {

    private Button back;
    private Button play;
    private Button enter;
    private RadioButton easy;
    private RadioButton medium;
    private RadioButton hard;
    private RadioButton sprite1;
    private RadioButton sprite2;
    private RadioButton sprite3;
    private TextView result;
    private TextView error;
    private EditText editText;
    private String enteredName;

    private boolean checkName = false;
    private boolean checkDifficulty = false;
    private boolean checkSprite = false;
    private boolean fromEnd = false;

    //These are the attributes you need to access for the game screen
    private static String name;
    private static int difficulty;
    private static String sprite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_customization);
        back = findViewById(R.id.backToMainPage);
        enter = findViewById(R.id.enterButton);
        play = findViewById(R.id.playButton);

        Intent n = getIntent();
        if (n.hasExtra("fromEnd")) {
            Bundle bFetch = n.getExtras();
            name = bFetch.getString("name");
            sprite = bFetch.getString("sprite");
            fromEnd = true;
            checkName = true;
            checkSprite = true;
            enter.setEnabled(false);
            result = findViewById(R.id.showName);
            String sentence = "Your name is: " + name;
            result.setText(sentence);
        }

        easy = findViewById(R.id.easyButton);
        medium = findViewById(R.id.mediumButton);
        hard = findViewById(R.id.hardButton);
        sprite1  = findViewById(R.id.sprite1);
        sprite2 = findViewById(R.id.sprite2);
        sprite3 = findViewById(R.id.sprite3);
        if (!fromEnd) {
            setButtonsNew();
        } else {
            setButtonsFromEnd();
        }

        back.setOnClickListener(
                v -> {
                    Intent i = new Intent(CharacterCustomization.this, MainActivity.class);
                    startActivity(i);
                }
        );
        enter.setOnClickListener(
                v -> nameCheck()
        );
        play.setOnClickListener(
                v -> {
                    if (!fromEnd) {
                        nameCheck();
                        spriteCheck();
                        difficultyCheck();
                        finalCheck();
                    } else {
                        fromEndCheck();
                    }
                }
        );
    }

    public void nameCheck() {
        editText = findViewById(R.id.editTextTextPersonName);
        enteredName = editText.getText().toString();
        result = findViewById(R.id.showName);
        boolean nameChecker = nameCheckHelper(enteredName);
        if (!nameChecker) {
            String invalid = "Entered name is invalid.";
            result.setText(invalid);
            checkName = false;
        } else {
            String sentence = "Your name is: " + enteredName;
            result.setText(sentence);
            checkName = true;
            easy.setEnabled(true);
            medium.setEnabled(true);
            hard.setEnabled(true);
            sprite1.setEnabled(true);
            sprite2.setEnabled(true);
            sprite3.setEnabled(true);
        }
    }

    public static boolean nameCheckHelper(String s) {
        return !(s == null || s.isBlank());
    }

    public void spriteCheck() {
        if (spriteCheckHelper(checkName)) {
            if (!sprite1.isChecked() && !sprite2.isChecked() && !sprite3.isChecked()) {
                error = findViewById(R.id.errorDiff);
                String errorMessage = "Make sure you have chosen a sprite.";
                error.setText(errorMessage);
                checkSprite = false;
            } else {
                checkSprite = true;
            }
        }

    }

    public static boolean spriteCheckHelper(boolean checker) {
        return checker;
    }

    public void difficultyCheck() {
        if (difficultyCheckHelper(checkName)) {
            if (!easy.isChecked() && !medium.isChecked() && !hard.isChecked()) {
                error = findViewById(R.id.errorDiff);
                String errorMessage = "Make sure you have chosen a difficulty.";
                error.setText(errorMessage);
                checkDifficulty = false;
            } else {
                checkDifficulty = true;
            }
        }
    }

    public static boolean difficultyCheckHelper(boolean checker) {
        return checker;
    }

    public void finalCheck() {
        if (checkName && checkDifficulty && checkSprite) {

            difficulty = correctDifficulty(easy, medium);

            if (sprite1.isChecked()) {
                sprite = "Sprite 1";
            } else if (sprite2.isChecked()) {
                sprite = "Sprite 2";
            } else {
                sprite = "Sprite 3";
            }

            name = enteredName;

            Intent i = new Intent(CharacterCustomization.this, Game.class);
            Bundle send = new Bundle();
            send.putString("name", enteredName);
            send.putInt("difficulty", difficulty);
            send.putString("sprite", sprite);
            i.putExtras(send);
            startActivity(i);
        }
    }

    public void fromEndCheck() {
        if (!easy.isChecked() && !medium.isChecked() && !hard.isChecked()) {
            error = findViewById(R.id.errorDiff);
            String errorMessage = "Make sure you have chosen a difficulty.";
            error.setText(errorMessage);
            checkDifficulty = false;
        } else {
            checkDifficulty = true;
        }
        difficulty = correctDifficulty(easy, medium);
        if (checkName && checkDifficulty && checkSprite) {
            Intent i = new Intent(CharacterCustomization.this, Game.class);
            Bundle send = new Bundle();
            send.putString("name", name);
            send.putInt("difficulty", difficulty);
            send.putString("sprite", sprite);
            i.putExtras(send);
            startActivity(i);
        }
    }

    public void setButtonsNew() {
        easy.setEnabled(false);
        medium.setEnabled(false);
        hard.setEnabled(false);
        sprite1.setEnabled(false);
        sprite2.setEnabled(false);
        sprite3.setEnabled(false);
    }

    public void setButtonsFromEnd() {
        easy.setEnabled(true);
        medium.setEnabled(true);
        hard.setEnabled(true);
        sprite1.setEnabled(false);
        sprite2.setEnabled(false);
        sprite3.setEnabled(false);
        if (sprite == "Sprite 1") {
            sprite1.setChecked(true);
        } else if (sprite == "Sprite 2") {
            sprite2.setChecked(true);
        } else {
            sprite3.setChecked(true);
        }
    }


    public static int correctDifficulty(RadioButton b1, RadioButton b2) {
        if (b1.isChecked()) {
            return 0;
        } else if (b2.isChecked()) {
            return 1;
        } else {
            return 2;
        }
    }

    public static int getDifficulty() {
        return difficulty;
    }
    public static String getSprite() {
        return sprite;
    }
    public static String getName() {
        return name;
    }

}