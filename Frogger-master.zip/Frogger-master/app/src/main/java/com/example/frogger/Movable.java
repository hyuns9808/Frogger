package com.example.frogger;

public interface Movable {
    public void move();
}
