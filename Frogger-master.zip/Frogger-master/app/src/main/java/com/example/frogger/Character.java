package com.example.frogger;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Character implements Renderable {

    private int charLives;
    private boolean isDead;
    private int charDiff;
    private String charName;
    private String charSprite;
    private int originX;
    private int originY;
    private int startingX;
    private int startingY;
    private int x;
    private int y;
    private Tilemap tileMap;
    private TileGrid tileGrid;
    private int maxWidth;
    private int maxHeight;
    private Context context;
    private Bitmap bmp;
    private Rect srcRect;
    private Rect drawRect;
    private int score;
    private int maxYTravelled;

    private static int numCollisionChecks = 0;

    public Character(Context context, int difficulty, String name, String sprite, Tilemap tileMap,
                     TileGrid tileGrid) {
        this.context = context;
        this.charDiff = difficulty;
        this.score = 0;

        setCharDiff(difficulty);

        isDead = false;

        this.charName = name;
        this.charSprite = sprite;
        this.tileMap = tileMap;
        this.tileGrid = tileGrid;

        srcRect = new Rect(0, 0, 16, 16);
        drawRect = new Rect();

        setCharaBitmap();

        if (tileMap == null) {
            maxWidth = 9;
            maxHeight = 14;
            originX = 0;
            originY = 0;
        } else {
            maxWidth = Tilemap.getWidth();
            maxHeight = Tilemap.getHeight();
            originX = tileMap.getOffSetX();
            originY = tileMap.getOffSetY();
        }
        // verify
        startingX = maxWidth / 2;
        startingY = 13;
        x = startingX;
        y = startingY;
        this.maxYTravelled = y;
    }

    // constructor for unit tests
    public Character(int difficulty) {
        this.charDiff = difficulty;

        setCharDiff(difficulty);

        srcRect = new Rect(0, 0, 16, 16);
        drawRect = new Rect();

        if (tileMap == null) {
            maxWidth = 9;
            maxHeight = 14;
            originX = 0;
            originY = 0;
        } else {
            maxWidth = Tilemap.getWidth();
            maxHeight = Tilemap.getHeight();
            originX = tileMap.getOffSetX();
            originY = tileMap.getOffSetY();
        }
        // verify
        x = maxWidth / 2;
        y = 13;
    }

    public void setCharaBitmap() {
        if (context == null) {
            return;
        }
        Resources res = context.getResources();
        bmp = null;
        if (res != null) {
            switch (charSprite) {
            case "Sprite 1": bmp = BitmapFactory.decodeResource(res, R.drawable.witch1);
                    break;
            case "Sprite 2": bmp = BitmapFactory.decodeResource(res, R.drawable.witch2);
                    break;
            case "Sprite 3": bmp = BitmapFactory.decodeResource(res, R.drawable.witch3);
                    break;
            default: bmp = BitmapFactory.decodeResource(res, R.drawable.witch1);
                    break;
            }
        }
    }

    public int getCharLives() {
        return charLives;
    }

    public void loseLife() {
        charLives = livesAfterCollision(charLives);
    }

    public void penalizeScore() {
        score = calculatePenalizedScore(score);
    }

    public static int scoreAfterGoal(int currentScore, int y) {
        if (tileType(y) == Tiles.GOAL) {
            currentScore = currentScore + 50;
        }
        return currentScore;
    }

    public static int livesAfterCollision(int charLives) {
        if (!hasDied(charLives)) {
            charLives--;
        }
        return charLives;
    }

    public static boolean hasDied(int charLives) {
        return charLives <= 0;
    }

    public static int calculatePenalizedScore(int score) {
        return score / 2;
    }

    public static boolean isCollidingWithVehicle(int x, int y, int vehicleX, int vehicleY,
                                                 boolean isLargeVehicle, boolean vehicleDirection) {
        if (!isLargeVehicle) {
            return x == vehicleX && y == vehicleY;
        } else {
            if (vehicleDirection) { // true is right
                return y == vehicleY && (x == vehicleX || x == vehicleX + 1);
            } else {
                return y == vehicleY && (x == vehicleX || x == vehicleX - 1);
            }
        }
    }

    public static boolean isCollidingWithVehicle(Character c, Vehicle v) {
        if (v instanceof LargeVehicle) {
            return isCollidingWithVehicle(c.getX(), c.getY(), v.getX(),
                    v.getY(), true, v.getDirection());
        } else {
            return isCollidingWithVehicle(c.getX(), c.getY(), v.getX(),
                    v.getY(), false, v.getDirection());
        }
    }

    public static boolean isCollidingWithLog(Character c, Log l) {
        return isCollidingWithLog(
                c.getX(), c.getY(),
                l.getX(), l.getY(),
                l.getWidth()
        );
    }

    public static boolean isCollidingWithLog(int cX, int cY, int lX, int lY, int lWidth) {
        if (cY == lY) {
            for (int i = 0; i < lWidth; i++) {
                if (cX == lX + i) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isCollidingWithRiver(int y) {
        if (tileType(y).equals(Tiles.RIVER)) {
            return true;
        }
        return false;
    }

    public static boolean isCollidingWithRiver(Character character) {
        return isCollidingWithRiver(character.y);
    }

    // returns true if this character collides with the given vehicle
    public boolean collide(Vehicle v) {
        if (hasDied(charLives)) {
            return false;
        }
        if (isCollidingWithVehicle(this, v)) {
            respawn();
            // we keep playing, we have lives remaining.
            penalizeScore();
            loseLife();
            return true;
        }
        return false;
    }

    public boolean collide(Log l) {
        if (hasDied(charLives)) {
            return false;
        }

        if (isCollidingWithLog(this, l)) {
            if (l.moveCheck()) {
                if (l.getDirection()) {
                    x++;
                    if (x > 8) {
                        respawn();
                        // we keep playing, we have lives remaining.
                        penalizeScore();
                        loseLife();
                        return true;
                    }
                } else {
                    x--;
                    if (x < 0) {
                        respawn();
                        // we keep playing, we have lives remaining.
                        penalizeScore();
                        loseLife();
                        return true;
                    }
                }
            }
            return true;
        }
        return false;
    }

    public boolean collideRiver() {
        if (hasDied(charLives)) {
            return false;
        }
        if (isCollidingWithRiver(this)) {
            respawn();
            // we keep playing, we have lives remaining.
            penalizeScore();
            loseLife();
            return true;
        }
        return false;
    }

    public static int[] positionAfterCollision(int x, int y, int startingX,
                                               int startingY, int charLives) {
        int[] position = {x, y};
        if (!hasDied(charLives)) { // only respawn when we are alive
            position[0] = startingX; // respawn coordinates
            position[1] = startingY; // respawn coordinates
        }
        return position;
    }

    public static int[] positionAfterLogCollisionUp(int prevX, int prevY) {
        int[] newPosition = {prevX, prevY + 1};
        return newPosition;
    }

    public static int[] positionAfterLogCollisionDown(int prevX, int prevY) {
        int[] newPosition = {prevX, prevY - 1};
        return newPosition;
    }

    public static boolean outOfBoundsOnLog(int x, int y, int logX, int logY, int logWidth) {
        return isCollidingWithLog(x, y, logX, logY, logWidth) && (x == 0 || x == 8);
    }

    public void respawn() {
        int[] position = positionAfterCollision(x, y, startingX, startingY, charLives);
        x = position[0];
        y = position[1];
        maxYTravelled = startingY; // reset the max y travelled so we can start earning points again
    }

    public int getScore() {
        return score;
    }

    public int getCharDiff() {
        return charDiff;
    }

    public String getCharName() {
        return charName;
    }

    public String getCharSprite() {
        return charSprite;
    }

    public void setCharDiff(int charDiff) {
        this.charDiff = charDiff;
        if (charDiff == 0) {
            this.charLives = 5;
        } else if (charDiff == 1) {
            this.charLives = 3;
        } else if (charDiff == 2) {
            this.charLives = 1;
        }
    }

    // move now returns boolean returning true if they are safe after moving.
    // if false, the player cannot play anymore
    public void move(int direction) {
        if (!hasDied(charLives)) { // character can only move when alive
            // directions: 0 = up; 1 = down; 2 = left; 3 = right
            int[] newPosition = calculateNewPosition(direction, x, y); // calculate new position
            x = newPosition[0]; // update x
            y = newPosition[1]; // update y

            // only update score and maxYTravelled if we don't collide.
            score = calculateNewScore(direction, y, maxYTravelled, score); // update score
            maxYTravelled = calculateNewMaxYTravelled(y, maxYTravelled); // update maxYTravelled
        }
    }

    public static int[] calculateNewPosition(int direction, int x, int y) {
        int[] position = {x, y};
        if (canMove(direction, x, y)) {
            if (direction == 0) { // up
                position[1] = position[1] - 1;
            } else if (direction == 1) { // down
                position[1] = position[1] + 1;
            } else if (direction == 2) { // left
                position[0] = position[0] - 1;
            } else if (direction == 3) { // right
                position[0] = position[0] + 1;
            }
        }
        return position;
    }

    public static int calculateNewMaxYTravelled(int y, int maxYTravelled) {
        if (newHeightReached(y, maxYTravelled)) {
            maxYTravelled = y;
        }
        return maxYTravelled;
    }

    public static int calculateNewScore(int direction, int y, int maxYTravelled, int score) {
        if (direction == 0) {
            int increment = scoreIncrement(y);
            if (newHeightReached(y, maxYTravelled)) {
                score += increment;
            }
        }
        return score;
    }

    public static int scoreIncrement(int y) {
        // lanes speeds and heights
        // speed = 1 height = 8
        // speed = 2 height = 9
        // speed = 3 height = 10
        // speed = 3 height = 11
        // speed = 2 height = 12
        // speed = 1 height = 13
        int increment;
        if (y == 13 || y == 8) {
            increment = 1;
        } else if (y == 12 || y == 9) {
            increment = 2;
        } else if (y == 11 || y == 10) {
            increment = 3;
        } else {
            increment = 1;
        }
        return increment;
    }

    public static boolean newHeightReached(int y, int maxYTravelled) {
        return y < maxYTravelled;
    }

    public static boolean canMove(int direction, int x, int y) {
        if (direction == 0) {
            return (y > 0);
        } else if (direction == 1) {
            return y < Tilemap.getHeight() - 1;
        } else if (direction == 2) {
            return x > 0;
        } else if (direction == 3) {
            return x < Tilemap.getWidth() - 1;
        } else {
            return false;
        }
    }

    public static Tiles tileType(int y) {
        Tiles answer = null;
        if (y == 13) {
            answer = Tiles.SAFE;
        } else if (y <= 12 && y >= 7) {
            answer = Tiles.ROAD;
        } else if (y == 6) {
            answer = Tiles.SAFE;
        } else if (y < 6 && y > 0) {
            answer = Tiles.RIVER;
        } else if (y == 0) {
            answer = Tiles.GOAL;
        }
        return answer;
    }

    public void draw(Canvas canvas) {

        drawRect = tileGrid.getCell(x, y);

        if (bmp != null) {
            canvas.drawBitmap(bmp, null, drawRect, null);
        }
    }

    public void setX(int value) {
        x = Math.max(Math.min(value, 8), 0);
    }

    public void setY(int value) {
        y = Math.max(Math.min(value, 13), 0);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
