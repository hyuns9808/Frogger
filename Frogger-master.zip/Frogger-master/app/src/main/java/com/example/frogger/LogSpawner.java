package com.example.frogger;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class LogSpawner {
    public static List<Log> generateDebug(Context context, TileGrid tileGrid) {

        List<Log> logSet = new ArrayList<Log>();

        for (int y = 1; y < 6; y++) {
            logSet.add(new Log(context, tileGrid, 3, 1, true, 1, y));
            logSet.add(new Log(context, tileGrid, 1, 1, true, 5, y));
        }

        return logSet;
    }

    public static List<Log> generateDefault(Context context, TileGrid tileGrid) {

        List<Log> logSet = new ArrayList<Log>();

        // LANE 1
        logSet.add(new Log(context, tileGrid, 4, 1, true, 0, 1));
        logSet.add(new Log(context, tileGrid, 1, 1, true, 5, 1));

        // LANE 2
        logSet.add(new Log(context, tileGrid, 3, 1, false, 1, 2));
        logSet.add(new Log(context, tileGrid, 3, 1, false, 5, 2));

        // LANE 3
        logSet.add(new Log(context, tileGrid, 2, 1, true, 1, 3));
        logSet.add(new Log(context, tileGrid, 2, 1, true, 4, 3));
        logSet.add(new Log(context, tileGrid, 2, 1, true, 6, 3));

        // LANE 4
        logSet.add(new Log(context, tileGrid, 4, 2, true, 0, 4));
        logSet.add(new Log(context, tileGrid, 1, 2, true, 5, 4));

        // LANE 5
        logSet.add(new Log(context, tileGrid, 4, 1, false, 0, 5));
        logSet.add(new Log(context, tileGrid, 1, 1, false, 5, 5));

        return logSet;
    }
}
