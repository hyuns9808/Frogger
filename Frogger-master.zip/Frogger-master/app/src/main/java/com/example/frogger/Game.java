package com.example.frogger;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.frogger.databinding.ActivityGameBinding;

public class Game extends AppCompatActivity {
    private ActivityGameBinding binding;
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // INITIALIZATION
        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        Bundle bFetch = i.getExtras();
        Integer difficulty = bFetch.getInt("difficulty");
        String charName = bFetch.getString("name");
        String sprite = bFetch.getString("sprite");

        binding = ActivityGameBinding.inflate(getLayoutInflater());

        // DRAWING THE TILEMAP ON STARTUP

        gameView = new GameView(this, bFetch, this);

        // Forwards game status information to a new manager in GameView

        setContentView(gameView);
    }
}

