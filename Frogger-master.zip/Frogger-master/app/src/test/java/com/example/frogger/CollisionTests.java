package com.example.frogger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.Before;

public class CollisionTests {

    @Test
    public void testLivesAfterCollision() {
        int lives = 0;
        assertEquals(0, Character.livesAfterCollision(lives));
        lives = 2;
        assertEquals(1, Character.livesAfterCollision(lives));
    }

    @Test
    public void testHasDied() {
        int lives = 0;
        assertTrue(Character.hasDied(lives));
    }

    @Test
    public void testHasNotDied() {
        int lives = 3;
        assertFalse(Character.hasDied(lives));
    }

    @Test
    public void testPenalizedScore() {
        int score = 20;
        assertEquals(10, Character.calculatePenalizedScore(score));
    }

    @Test
    public void testCollisionsWithVehicles() {
        int characterX = 2;
        int characterY = 2;
        int vehicleX = 2;
        int vehicleY = 2;
        assertTrue(Character.isCollidingWithVehicle(characterX, characterY,
                vehicleX, vehicleY, true, false));
    }

    @Test
    public void testSafeFromCollisions() {
        int characterX = 2;
        int characterY = 3;
        int vehicleX = 4;
        int vehicleY = 3;
        assertFalse(Character.isCollidingWithVehicle(characterX, characterY,
                vehicleX, vehicleY, true, true));
    }

    @Test
    public void testCollisionWithRiver() {
        int y = 3;
        assertTrue(Character.isCollidingWithRiver(y));
    }

    @Test
    public void testSafeFromRiver() {
        int y = 9;
        assertFalse(Character.isCollidingWithRiver(y));
    }

    @Test
    public void testCorrectPosition() {
        int x = 8;
        int y = 4;
        int startX = 0;
        int startY = 0;
        int charLives = 9;
        assertEquals(0, Character.positionAfterCollision(x, y,
                startX, startY, charLives)[0]);
        assertEquals(0, Character.positionAfterCollision(x, y,
                startX, startY, charLives)[1]);

    }

    @Test
    public void testPositionIfDied() {
        int x = 8;
        int y = 4;
        int startX = 0;
        int startY = 0;
        int charLives = 0;
        assertEquals(8, Character.positionAfterCollision(x, y,
                startX, startY, charLives)[0]);
        assertEquals(4, Character.positionAfterCollision(x, y,
                startX, startY, charLives)[1]);
    }

    @Test

    public void testGameOver(){
        int charLives = 0;
        assertTrue(GameView.willGameTerminate(charLives));
    }

    @Test

    public void testGameNotOver(){
        int charLives = 4;
        assertFalse(GameView.willGameTerminate(charLives));
    }
}
