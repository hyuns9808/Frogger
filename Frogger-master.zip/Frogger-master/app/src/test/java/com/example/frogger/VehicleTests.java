package com.example.frogger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.Before;

public class VehicleTests {

    @Test
    public void correctSpeed() {
        int y = 8;
        assertEquals(1, Vehicle.calculateSpeed(y));
        y = 12;
        assertEquals(2, Vehicle.calculateSpeed(y));
        y = 10;
        assertEquals(3, Vehicle.calculateSpeed(y));
    }

    @Test
    public void correctDirection() {
        int y = 9;
        assertTrue(Vehicle.calculateDirection(y));
        y = 10;
        assertFalse(Vehicle.calculateDirection(y));
    }

    @Test
    public void correctStartingPosition() {
        int y = 11;
        assertEquals(8, Vehicle.calculateStartingX(y));
        y = 12;
        assertEquals(0, Vehicle.calculateStartingX(y));
    }

    @Test
    public void correctScoreIncrementForSpeed1Lanes() {
        assertEquals(1, Character.scoreIncrement(13));
        assertEquals(1, Character.scoreIncrement(8));
    }

    @Test
    public void correctScoreIncrementForSpeed2Lanes() {
        assertEquals(2, Character.scoreIncrement(9));
        assertEquals(2, Character.scoreIncrement(12));
    }

    @Test
    public void correctScoreIncrementForSpeed3Lanes() {
        assertEquals(3, Character.scoreIncrement(10));
        assertEquals(3, Character.scoreIncrement(11));
    }

}
