package com.example.frogger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class LogGoalTests {

    @Test
    public void testLogCollision() {
        int x = 5;
        int y = 5;
        int logX = 4;
        int logY = 5;
        int lWidth = 3;
        assertTrue(Character.isCollidingWithLog(x, y, logX, logY, lWidth));
    }

    @Test
    public void testLogNotColliding() {
        int x = 3;
        int y = 5;
        int logX = 4;
        int logY = 5;
        int lWidth = 3;
        assertFalse(Character.isCollidingWithLog(x, y, logX, logY, lWidth));
    }

    @Test
    public void testLogProtection() {
        Character testChara = new Character(null, 1, "jane doe", "sprite 1", null, null);
        testChara.setX(2);
        testChara.setY(3);

        Log testLog = new Log(null, null, 1, 0, true, 2, 3);

        int livesA = testChara.getCharLives();
        boolean bool = (!testChara.collide(testLog) && testChara.collideRiver());
        int livesB = testChara.getCharLives();
        assertEquals(livesA, livesB);

        testChara.setX(1);
        testChara.setY(3);
    }

    @Test
    public void testLogNoProtection() {
        Character testChara = new Character(null, 1, "jane doe", "sprite 1", null, null);
        testChara.setX(1);
        testChara.setY(3);

        Log testLog = new Log(null, null, 1, 0, true, 2, 3);
        int livesA = testChara.getCharLives();
        boolean bool = (!testChara.collide(testLog) && testChara.collideRiver());
        int livesB = testChara.getCharLives();

        assertNotEquals(livesA, livesB);
    }

    @Test
    public void testScoreAfterGoal() {
        int currScore = 20;
        int y = 0;
        assertEquals(70, Character.scoreAfterGoal(currScore, y));
    }

    @Test
    public void testScoreWithNoGoal() {
        int currScore = 39;
        int y = 2;
        assertNotEquals(89, Character.scoreAfterGoal(currScore, y));
    }

    @Test
    public void testCanMoveOnLog() {
        int gameTick = 9;
        int speedDebug = 3;
        int gameFPS = 3;
        int logSpeed = 1;
        assertTrue(Log.isRightTickToMove(gameTick, speedDebug, gameFPS, logSpeed));
    }

    @Test
    public void testCannotMoveOnLog() {
        int gameTick = 2;
        int speedDebug = 23;
        int gameFPS = 9;
        int logSpeed = 1;
        assertFalse(Log.isRightTickToMove(gameTick, speedDebug, gameFPS, logSpeed));
    }

    @Test
    public void testCharacterMovesWithLog() {
        boolean direction = true;
        int x = 10;
        int MAX_WIDTH = 4;
        int width = 12;
        assertEquals(-3, Log.moveHelper(direction, x, width, MAX_WIDTH));
    }

    @Test
    public void testPositionAfterMovingUpOntoLog() {
        int oldX = 4;
        int oldY = 6;
        int[] newPosition = {4, 7};
        assertEquals(newPosition[0], Character.positionAfterLogCollisionUp(oldX, oldY)[0]);
        assertEquals(newPosition[1], Character.positionAfterLogCollisionUp(oldX, oldY)[1]);
    }

    @Test
    public void testPositionAfterMovingDownOntoLog() {
        int oldX = 4;
        int oldY = 7;
        int[] newPosition = {4, 6};
        assertEquals(newPosition[0], Character.positionAfterLogCollisionDown(oldX, oldY)[0]);
        assertEquals(newPosition[1], Character.positionAfterLogCollisionDown(oldX, oldY)[1]);
    }

    @Test
    public void testOutOfBoundsOnLog() {
        int x = 0;
        int y = 4;
        int logX = 0;
        int logY = 4;
        int logWidth = 3;
        assertTrue(Character.outOfBoundsOnLog(x, y, logX, logY, logWidth));
    }
}
