package com.example.frogger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class CharacterCustomizationTests {

    private CharacterCustomization c;
    private Character chara = new Character(5);
    @Test
    public void validName() {
        String invalid1 = "";
        String invalid2 = "                  ";
        String invalid3 = null;
        String valid1 = "Name";

        assertFalse(CharacterCustomization.nameCheckHelper(invalid1));
        assertFalse(CharacterCustomization.nameCheckHelper(invalid2));
        assertFalse(CharacterCustomization.nameCheckHelper(invalid3));
        assertTrue(CharacterCustomization.nameCheckHelper(valid1));

    }

    @Test
    public void spriteCheck() {
        String enteredNameEx = "";
        String enteredNameEx2 = "Name";
        boolean check1 = enteredNameEx.isBlank();  //this is if the name entered
        boolean check2 = enteredNameEx2.isBlank(); //this is if the name is not entered

        assertTrue(CharacterCustomization.spriteCheckHelper(check1));
        assertFalse(CharacterCustomization.spriteCheckHelper(check2));
    }
    @Test
    public void difficultyCheck() {
        String enteredNameEx = "";
        String enteredNameEx2 = "Name";
        boolean check1 = enteredNameEx.isBlank();  //this is if the name entered
        boolean check2 = enteredNameEx2.isBlank();

        assertTrue(CharacterCustomization.difficultyCheckHelper(check1));
        assertFalse(CharacterCustomization.difficultyCheckHelper(check2));
    }

    @Test
    public void livesCheck() {
        chara.setCharDiff(2);
        assertEquals(1, chara.getCharLives());

        chara.setCharDiff(1);
        assertEquals(3, chara.getCharLives());

        chara.setCharDiff(0);
        assertEquals(5, chara.getCharLives());
    }

    @Test
    public void onGoalTile() {
        assertEquals(Tiles.GOAL, Character.tileType(0));
        assertNotEquals(Tiles.GOAL, Character.tileType(2));
    }

    @Test
    public void onRiverTile() {
        assertEquals(Tiles.RIVER, Character.tileType(2));
        assertNotEquals(Tiles.RIVER, Character.tileType(7));
    }

    @Test
    public void onRoadTile() {
        assertEquals(Tiles.ROAD, Character.tileType(11));
        assertNotEquals(Tiles.ROAD, Character.tileType(0));
    }

    @Test
    public void onSafeTile() {
        assertEquals(Tiles.SAFE, Character.tileType(6));
        assertNotEquals(Tiles.SAFE, Character.tileType(8));
    }
}
