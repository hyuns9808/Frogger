package com.example.frogger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Test;
import org.junit.Before;

public class CharacterTests {

    private int mapWidth;
    private int mapHeight;
    @Before
    public void setUp() {
        mapWidth = 9;
        mapHeight = 14;
    }

    private boolean outOfBoundsTestHelper(int direction, int x, int y) {
        return Character.canMove(direction, x, y);
    }

    @Test
    public void doesNotGoOutOfBoundsUp() {

        assertFalse(outOfBoundsTestHelper(0, 0, 0));
    }

    @Test
    public void doesNotGoOutOfBoundsDown() {

        assertFalse(outOfBoundsTestHelper(1, 0, 13));
    }

    @Test
    public void doesNotGoOutOfBoundsLeft() {

        assertFalse(outOfBoundsTestHelper(2, 0, 0));
    }

    @Test
    public void doesNotGoOutOfBoundsRight() {
        assertFalse(outOfBoundsTestHelper(3, 8, 0));
    }


    @Test
    public void increasesScoreNewHeight() {
        // simulating step up from tile y = 14 to y = 13 (entering road for the first time)
        // we expect score to increase by 1 in this case
        // player starts with 0 score

        // ***** Character info
        int score = 0;
        int oldX = 5;
        int oldY = 14;
        int direction = 0;
        int oldMaxYTravelled = oldY;
        // *****

        int[] newPosition = Character.calculateNewPosition(direction, oldX, oldY);
        int newY = newPosition[1];

        int newScoreExpected = 1;
        int newScoreActual = Character.calculateNewScore(direction, newY, oldMaxYTravelled, score);

        assertEquals("score did not update properly", newScoreExpected, newScoreActual);

    }

    @Test
    public void maxYTravelledUpdatesCorrectlyReachingNewHeight() {
        int oldX = 5;
        int oldY = 14;
        int direction = 0;
        int oldMaxYTravelled = oldY;

        int[] newPosition = Character.calculateNewPosition(direction, oldX, oldY);
        int newY = newPosition[1];

        int maxYTravelledExpected = 13;
        int newMaxYTravelled = Character.calculateNewMaxYTravelled(newY, oldMaxYTravelled);
        assertEquals("maxYTravelled did not update properly", maxYTravelledExpected, newMaxYTravelled);

    }

    @Test
    public void doesNotIncreaseScoreMovingDown() {
        // ***** Character info
        int score = 0;
        int oldX = 5;
        int oldY = 10;
        int direction = 1;
        int oldMaxYTravelled = oldY;
        // *****

        int[] newPosition = Character.calculateNewPosition(direction, oldX, oldY);
        int newY = newPosition[1];

        int newScoreExpected = 0;
        int newScoreActual = Character.calculateNewScore(direction, newY, oldMaxYTravelled, score);

        assertEquals("score should not have changed", newScoreExpected, newScoreActual);

    }

    @Test
    public void doesNotIncreaseScoreMovingLeft() {
        int score = 0;
        int oldX = 5;
        int oldY = 10;
        int direction = 2;
        int oldMaxYTravelled = oldY;
        // *****

        int[] newPosition = Character.calculateNewPosition(direction, oldX, oldY);
        int newY = newPosition[1];

        int newScoreExpected = 0;
        int newScoreActual = Character.calculateNewScore(direction, newY, oldMaxYTravelled, score);

        assertEquals("score should not have changed going left", newScoreExpected, newScoreActual);
    }

    @Test
    public void doesNotIncreaseScoreMovingRight() {
        int score = 0;
        int oldX = 5;
        int oldY = 10;
        int direction = 3;
        int oldMaxYTravelled = oldY;
        // *****

        int[] newPosition = Character.calculateNewPosition(direction, oldX, oldY);
        int newY = newPosition[1];

        int newScoreExpected = 0;
        int newScoreActual = Character.calculateNewScore(direction, newY, oldMaxYTravelled, score);

        assertEquals("score should not have changed going right", newScoreExpected, newScoreActual);
    }

    @Test
    public void doesNotIncreaseScoreMovingUpRevisitedHeight() {
        // ***** Character info
        int score = 0;
        int oldX = 5;
        int oldY = 14;
        int direction = 0;
        int oldMaxYTravelled = 12;
        // *****

        int[] newPosition = Character.calculateNewPosition(direction, oldX, oldY);
        int newY = newPosition[1];

        int newScoreExpected = 0;
        int newScoreActual = Character.calculateNewScore(direction, newY, oldMaxYTravelled, score);

        assertEquals(
                "score should not have updated as new height has not been reached",
                newScoreExpected,
                newScoreActual
        );
    }





}